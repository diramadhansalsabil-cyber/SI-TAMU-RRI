import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/** URL production Vercel — dipakai fallback QR jika admin buka dari link preview */
export const PRODUCTION_APP_URL = "https://si-tamu-rri-kdi.vercel.app";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(date));
}

export function formatDateShort(date: string | Date): string {
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date(date));
}

export function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[<>]/g, "")
    .replace(/javascript:/gi, "")
    .replace(/on\w+=/gi, "");
}

export function isVercelPreviewUrl(url: string): boolean {
  try {
    const hostname = new URL(url).hostname;
    return (
      hostname.includes("-projects.vercel.app") ||
      /-[a-z0-9]{8,}-/.test(hostname)
    );
  } catch {
    return false;
  }
}

export function getAppUrl(): string {
  const configured = process.env.NEXT_PUBLIC_APP_URL?.trim();
  if (configured) {
    return configured.replace(/\/$/, "");
  }

  if (typeof window !== "undefined") {
    const origin = window.location.origin;
    if (!isVercelPreviewUrl(origin)) {
      return origin;
    }
    return PRODUCTION_APP_URL;
  }

  return PRODUCTION_APP_URL;
}
